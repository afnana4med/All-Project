
public class SussexCarPark implements CarPark {

    // initialising the car park with linklist stack: LIFO
    private final Stack<String> carPark = new LinkedListStack();

    // initialising the road way with Circular Queue: FIFO
    private final CircularArrayQueue road = new CircularArrayQueue(100);

    // As the car arrive push that into the car park Stack and return the size of car park
    @Override
    public int arrive(String carOwner) {
        carPark.push(carOwner);
        System.out.println(carOwner + " goes into car park");
        return carPark.size();
    }

    // checking that is there any car in car park stack
    @Override
    public String leave(String carOwner) {
        if (carPark.isEmpty()) {
            System.out.println("The car park is empty");
            return "";
        }

        // initialising the car found false and assuming no car on the road yet
        boolean foundCar = false;
        String carOnRoad = "";

        // Moving cars from car park to road until the desired car is found or car park is empty
        while (!carPark.isEmpty()) {
            String currentCar = carPark.pop();
            if (currentCar.equals(carOwner)) {
                foundCar = true;
                System.out.println(carOwner + " leaves");
                break;
            }

            carOnRoad = carOnRoad + currentCar + "-";
            System.out.println(currentCar + " goes into the road");
            road.enqueue(currentCar);
        }

        // If there is car on the road way push them back in to car park stack
        while (!road.isEmpty()) {
            String owner = road.dequeue();
            carPark.push(owner);
            System.out.println(owner + " goes into the car park");
        }

        // If car found it goes to carOnroad
        if (foundCar) {
            return carOnRoad;
        } else {
            // if not found display the error message
            System.out.println("Error! " + carOwner + " is not in the car park");
            return null;
        }
    }
}



