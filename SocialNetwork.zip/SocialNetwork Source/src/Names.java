public class Names {
    public static final int ABEL = 0;
    public static final int BINA = 1;
    public static final int CATO = 2;
    public static final int DANA = 3;
    public static final int EDEN = 4;
    public static final int FERN = 5;
    public static final int GENO = 6;
    public static final int HEDY = 7;
    public static final int INEZ = 8;
    public static final int JODI = 9;

    public static final String[] networkMembers = {
            "Abel",
            "Bina",
            "Cato",
            "Dana",
            "Eden",
            "Fern",
            "Geno",
            "Hedy",
            "Inez",
            "Jodi"
    };
}
