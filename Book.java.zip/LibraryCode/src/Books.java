public class Books {
    public static final String[] books =
        {
            "Don Quixote,Miguel de Cervantes,1605",
            "Robinson Crusoe,Daniel Defoe,1719",
            "Pride and Prejudice,Jane Austen,1813",
            "Frankenstein,Mary Shelley,1818",
            "Wuthering Heights,Emily Bronte,1847",
            "Jane Eyre,Charlotte Bronte,1847",
            "Moby Dick,Herman Melville,1851",
            "Madame Bovary,Gustave Flaubert,1856",
            "War and Peace,Leo Tolstoy,1869",
            "The Adventures of Huckleberry Finn,Mark Twain,1884",
            "Dracula,Bram Stoker,1897",
            "The Great Gatsby,F. Scott Fitzgerald,1925",
            "To Kill a Mockingbird,Harper Lee,1960",
            "One Hundred Years of Solitude,Gabriel Garcia Marquez,1967",
            "Beloved,Toni Morrison,1987"
        };
}
